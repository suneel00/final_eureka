package com.cts.WishListService.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "favourite")
public class Wishlist {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long wishId;
	private String userName;
	private String trackName;
	private int track_number;
	private String artist_name;
	
	
	public long getWishId() {
		return wishId;
	}
	public void setWishId(long wishId) {
		this.wishId = wishId;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getTrackName() {
		return trackName;
	}
	public void setTrackName(String trackName) {
		this.trackName = trackName;
	}
	public int getTrack_number() {
		return track_number;
	}
	public void setTrack_number(int track_number) {
		this.track_number = track_number;
	}
	public String getArtist_name() {
		return artist_name;
	}
	public void setArtist_name(String artist_name) {
		this.artist_name = artist_name;
	}
	public Wishlist(long wishId, String userName, String trackName, int track_number,
			String artist_name) {
		super();
		this.wishId = wishId;	
		this.userName = userName;
		this.trackName = trackName;
		this.track_number = track_number;
		this.artist_name = artist_name;
	}
	public Wishlist() {
		super();
	}
	

	
}
