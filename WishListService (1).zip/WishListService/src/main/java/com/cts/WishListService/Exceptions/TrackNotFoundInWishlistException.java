package com.cts.WishListService.Exceptions;

public class TrackNotFoundInWishlistException extends RuntimeException {
	public TrackNotFoundInWishlistException(String message) {
		super(message);
	}

}
