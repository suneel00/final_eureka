package com.cts.WishListService.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;


import com.cts.WishListService.Model.Wishlist;

public interface WishlistRepo extends JpaRepository<Wishlist, Long>{
	
	//@Query(value = "SELECT * FROM favourite WHERE user_name = ?1 " , nativeQuery= true )
	
		List<Wishlist> findAllByUserName(@Param("username") String userName);

		List<Wishlist> findByUserNameAndTrackName(String userName, String trackName);
}
