package com.cts.WishListService.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.WishListService.Exceptions.TrackAlreadyExistException;
import com.cts.WishListService.Exceptions.TrackNotFoundInWishlistException;
import com.cts.WishListService.Model.Wishlist;
import com.cts.WishListService.Repository.WishlistRepo;

import ch.qos.logback.classic.Logger;

@Service
public class WishlistServiceImpl implements WishlistService {
	
	@Autowired
	private WishlistRepo wishlistRepo;

	
	@Override
	public Wishlist addTrack(Wishlist newTrack)throws TrackAlreadyExistException {
		List<Wishlist> existTrack = this.wishlistRepo.findByUserNameAndTrackName(newTrack.getUserName(), newTrack.getTrackName());
		if(existTrack.isEmpty()) {
			
		return wishlistRepo.save(newTrack);
		}
		else {
			throw new TrackAlreadyExistException("Track already exists in your wishlist");
		}	
	}

	@Override
	public List<Wishlist> getAllfavTrackByUsername(String userName) {
		List<Wishlist> track = wishlistRepo.findAllByUserName(userName);
		if(track == null) {
			throw new TrackNotFoundInWishlistException("Your track is not here");
		}
		return track;
	}


	@Override
	public String deleteTrack(long wishId) {
		wishlistRepo.deleteById(wishId);
		return "track deleted";
	}

}
