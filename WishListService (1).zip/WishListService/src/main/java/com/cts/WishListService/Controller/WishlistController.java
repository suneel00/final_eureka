package com.cts.WishListService.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cts.WishListService.Model.Wishlist;
import com.cts.WishListService.ResponseHandler.ResponseHandler;
import com.cts.WishListService.Services.WishlistService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@SecurityRequirement(name = "Bearer Authentication")
@RequestMapping("/wishlist")
@CrossOrigin
public class WishlistController {
	
	@Autowired
	private WishlistService wishlistService;

	@PostMapping("/add")
	public ResponseEntity<Object> addTrack(@RequestBody Wishlist newTrack) {
		try {
			return ResponseHandler.generateResponse("Track is added in wish list", HttpStatus.CREATED,
					wishlistService.addTrack(newTrack));
		} catch (Exception e) {
			System.out.println("bad request" +e);
			return new ResponseEntity<>("bad request" +e, HttpStatus.CONFLICT);
		}
	}


	@GetMapping("/track/{username}")
	public ResponseEntity<Object> getAllfavTrackByUsername(@PathVariable("username") String userName) {
		try {
			List<Wishlist> track = wishlistService.getAllfavTrackByUsername(userName);
			return ResponseHandler.generateResponse("Your fav. tracklist is here", HttpStatus.OK, track);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@DeleteMapping("/delete/{wishId}")
	public ResponseEntity<Object> deleteTrack(@PathVariable("wishId") long wishId) {
		try {
			String delTrack = wishlistService.deleteTrack(wishId);
			return ResponseHandler.generateResponse("your fav. track is deleted", HttpStatus.OK,
					wishlistService.deleteTrack(wishId));
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	
}
