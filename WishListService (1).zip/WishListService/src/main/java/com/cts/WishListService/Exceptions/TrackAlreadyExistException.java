package com.cts.WishListService.Exceptions;

public class TrackAlreadyExistException extends RuntimeException {
	public TrackAlreadyExistException(String message) {
		super(message);
	}
}