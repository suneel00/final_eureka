package com.cts.WishListService.Services;

import java.util.List;

import com.cts.WishListService.Model.Wishlist;


public interface WishlistService {

	Wishlist addTrack(Wishlist newTrack); // add fav track

	List<Wishlist> getAllfavTrackByUsername(String userName); // fav track from wish list

	String deleteTrack(long wishId);
}
