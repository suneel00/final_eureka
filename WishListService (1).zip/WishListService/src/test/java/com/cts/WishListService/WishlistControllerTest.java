package com.cts.WishListService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


import com.cts.WishListService.Controller.WishlistController;
import com.cts.WishListService.Model.Wishlist;
import com.cts.WishListService.Services.WishlistService;

@SpringBootTest
public class WishlistControllerTest {
	
	
	
	 @InjectMocks
	    private WishlistController wishlistController;
	 
	    @Mock
	    private WishlistService wishlistService;
	 
	    @Test
	    public void testAddTrack() {
	        Wishlist newTrack = new Wishlist();
	        when(wishlistService.addTrack(any())).thenReturn(newTrack);
	 
	        ResponseEntity<Object> response = wishlistController.addTrack(newTrack);
	 
	        assertEquals(HttpStatus.CREATED, response.getStatusCode());
	    }
	 
	    @Test
	    public void testGetAllFavTrackByUsername() {
	        String username = "testUser";
	        List<Wishlist> expectedTracks = Collections.singletonList(new Wishlist());
	        when(wishlistService.getAllfavTrackByUsername(username)).thenReturn(expectedTracks);
	 
	        ResponseEntity<Object> response = wishlistController.getAllfavTrackByUsername(username);
	 
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        //assertEquals(expectedTracks, response.getBody());
	    }
	 
	    @Test
	    public void testDeleteTrack() {
	        long favId = 1;
	        when(wishlistService.deleteTrack(favId)).thenReturn("Deleted");
	 
	        ResponseEntity<Object> response = wishlistController.deleteTrack(favId);
	 
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	    }
	}

