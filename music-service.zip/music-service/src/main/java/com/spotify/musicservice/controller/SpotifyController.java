package com.spotify.musicservice.controller;

import com.spotify.musicservice.dto.Album;
import com.spotify.musicservice.service.SpotifyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@Slf4j
@RequestMapping("/api/v1.0/musictrack")
public class SpotifyController {
    private final SpotifyService spotifyService;

    @Autowired
    public SpotifyController(SpotifyService spotifyService) {

        this.spotifyService = spotifyService;
    }

    /*@GetMapping("/login")
    public ResponseEntity<Object> getSpotifyAccessToken() {
        // Obtain the access token
            return new ResponseEntity<>(spotifyService.getSpotifyAccessToken(), HttpStatus.OK);
    }*/

    @GetMapping("/gettollywood-songs")
    public ResponseEntity<Object> getTopTeluguSongs() {
            return new ResponseEntity<>(spotifyService.getTopTeluguSongs(), HttpStatus.OK);
    }
    @GetMapping("/getbollywood-songs")
    public ResponseEntity<Object> getAllHindiSongs(){
        return new ResponseEntity<>(spotifyService.getAllHindiSongs(), HttpStatus.OK);
    }
    @GetMapping("/discoverWeeklyPlaylist")
    public ResponseEntity<Object> getTop50GlobalSongs(){
        return new ResponseEntity<>(spotifyService.getTop50GlobalSongs(), HttpStatus.OK);
    }

    @GetMapping("/todayTopHitsPlaylist")
    public ResponseEntity<Object> getTodayTopHits() {
            return new ResponseEntity<>(spotifyService.getTodayTopHits(), HttpStatus.OK);
    }

    @GetMapping("/track")
    public ResponseEntity<Object> getTrack(@RequestParam String trackId ) {
        return new ResponseEntity<>(spotifyService.getTrack(trackId), HttpStatus.OK);
    }

    @GetMapping("/search")
    public ResponseEntity<Object> search(@RequestParam String query) {
            return new ResponseEntity<>(spotifyService.search(query), HttpStatus.OK);
    }
    @GetMapping("/album/{albumId}")
    public ResponseEntity<Album> getAlbumById(@PathVariable String albumId){
        Album album = spotifyService.getAlbum(albumId);
        if (album != null){
            return ResponseEntity.ok(album);
        }
        else {
            return ResponseEntity.notFound().build();
        }
    }
}
