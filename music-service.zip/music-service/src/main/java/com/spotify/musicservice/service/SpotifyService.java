package com.spotify.musicservice.service;

import com.spotify.musicservice.dto.Album;
import com.spotify.musicservice.dto.SpotifyPlaylist;
import com.spotify.musicservice.dto.Track;
import com.spotify.musicservice.model.SpotifyAccessToken;

public interface SpotifyService {
    SpotifyAccessToken getSpotifyAccessToken();

    SpotifyPlaylist getTopTeluguSongs();

    SpotifyPlaylist getTodayTopHits();
    SpotifyPlaylist getAllHindiSongs();

    SpotifyPlaylist getTop50GlobalSongs();

    Track getTrack(String trackId);

    Object search(String query);

    Album getAlbum(String albumId);
}
