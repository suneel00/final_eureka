//package com.spotify.musicservice.Service;
//
//import com.spotify.musicservice.dto.SpotifyPlaylist;
//import com.spotify.musicservice.exception.ResourceNotFoundException;
//import com.spotify.musicservice.model.SpotifyAccessToken;
//import com.spotify.musicservice.repository.SpotifyAccessTokenRepository;
//import com.spotify.musicservice.service.SpotifyServiceImpl;
//import org.junit.jupiter.api.Test;
//        import org.mockito.InjectMocks;
//        import org.mockito.Mock;
//        import org.springframework.boot.test.context.SpringBootTest;
//        import org.springframework.http.*;
//        import org.springframework.web.client.RequestCallback;
//        import org.springframework.web.client.ResponseExtractor;
//        import org.springframework.web.client.RestTemplate;
//
//        import java.net.URI;
//        import java.util.Base64;
//        import java.util.Optional;
//
//        import static org.junit.jupiter.api.Assertions.*;
//        import static org.mockito.ArgumentMatchers.any;
//        import static org.mockito.ArgumentMatchers.eq;
//        import static org.mockito.Mockito.*;
//
//@SpringBootTest
//public class SpotifyServiceImplTest {
//
//    @Mock
//    private SpotifyAccessTokenRepository spotifyAccessTokenRepository;
//
//    @Mock
//    private RestTemplate restTemplate;
//
//    @InjectMocks
//    private SpotifyServiceImpl spotifyService;
//
//    @Test
//    void testGetSpotifyAccessToken() {
//        // Mocking
//        SpotifyAccessToken mockToken = new SpotifyAccessToken();
//        when(restTemplate.postForEntity(anyString(), any(), eq(SpotifyAccessToken.class)))
//                .thenReturn(new ResponseEntity<>(mockToken, HttpStatus.OK));
//
//        // Test
//        SpotifyAccessToken result = spotifyService.getSpotifyAccessToken();
//
//        // Assertions
//        assertNotNull(result);
//        assertEquals(mockToken, result);
//        verify(spotifyAccessTokenRepository, times(1)).save(any());
//    }
//
//    @Test
//    void testGetSpotifyAccessTokenException() {
//        // Mocking
//        when(restTemplate.postForEntity(anyString(), any(), eq(SpotifyAccessToken.class)))
//                .thenReturn(new ResponseEntity<>(HttpStatus.NOT_FOUND));
//
//        // Test and Assertions
//        assertThrows(ResourceNotFoundException.class, () -> spotifyService.getSpotifyAccessToken());
//    }
//
//    @Test
//    void testGetAllHindiSongs() {
//        // Mocking
//        when(spotifyAccessTokenRepository.findById(1L))
//                .thenReturn(Optional.of(new SpotifyAccessToken("Token")));
//        when(restTemplate.exchange(any(RequestEntity.class), eq(SpotifyPlaylist.class)))
//                .thenReturn(new ResponseEntity<>(new SpotifyPlaylist(), HttpStatus.OK));
//
//        // Test
//        SpotifyPlaylist result = spotifyService.getAllHindiSongs();
//
//        // Assertions
//        assertNotNull(result);
//        verify(restTemplate, times(1)).exchange(any(RequestEntity.class), eq(SpotifyPlaylist.class));
//    }
//}