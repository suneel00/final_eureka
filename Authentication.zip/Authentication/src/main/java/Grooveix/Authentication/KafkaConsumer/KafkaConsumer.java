package Grooveix.Authentication.KafkaConsumer;

import Grooveix.Authentication.Exception.UserAlreadyExistException;
import Grooveix.Authentication.Repo.AuthRepo;
import Grooveix.Authentication.Service.AuthServiceImpl;
import Grooveix.Authentication.model.AuthUser;
import Grooveix.Authentication.model.UserDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import com.google.gson.Gson;

@Configuration
public class KafkaConsumer {
	@Autowired
	AuthRepo authRepo;

	@KafkaListener(topics = "music", groupId = "authgroup")
	public void updatedLocation(String value) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		UserDetails fullUser = objectMapper.readValue(value, UserDetails.class);
		System.out.println(value);
		AuthUser user = new AuthUser(fullUser.getEmail(),fullUser.getPassword());
		System.out.println(user);
		authRepo.save(user);
	}
}