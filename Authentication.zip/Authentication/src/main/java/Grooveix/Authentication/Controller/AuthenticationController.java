package Grooveix.Authentication.Controller;

import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import Grooveix.Authentication.Exception.UserNotFoundException;
import Grooveix.Authentication.Service.AuthService;
import Grooveix.Authentication.config.JwtTokenGenerator;
import Grooveix.Authentication.model.AuthUser;

@RestController
@RequestMapping("/Grooveix")
public class AuthenticationController {
	@Autowired
	AuthService authService;
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody AuthUser authUser){
		
		try {
			if(authUser.getEmail()== null||authUser.getPassword()==null ) {
			throw new UserNotFoundException("Email and Password are null");
		}
		boolean data=authService.getAuthenticUser(authUser.getEmail(),authUser.getPassword());
		
		if(data) {
			Map<String, String> token=new JwtTokenGenerator().generateToken(authUser);
			return new ResponseEntity<Map>(token, HttpStatus.OK);
		}else 
			if(data==false){
			throw new UserNotFoundException("Email or  Password mismatch");
		}
	}
	catch(UserNotFoundException e){
		System.out.println(e.getMessage());
		return new ResponseEntity("Invalid user", HttpStatus.UNAUTHORIZED);
		}
		return null;
	}

}
