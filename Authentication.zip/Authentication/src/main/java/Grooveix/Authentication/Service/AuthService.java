package Grooveix.Authentication.Service;

import Grooveix.Authentication.Exception.UserAlreadyExistException;
import Grooveix.Authentication.Exception.UserNotFoundException;
import Grooveix.Authentication.model.AuthUser;

public interface AuthService {
	AuthUser registerUser(AuthUser user) throws UserAlreadyExistException;
	boolean getAuthenticUser(String email, String password) throws UserNotFoundException;

}
