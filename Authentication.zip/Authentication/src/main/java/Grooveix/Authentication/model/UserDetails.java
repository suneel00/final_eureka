package Grooveix.Authentication.model;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

public class UserDetails {
    @Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(unique=true)
    private long userId;
    @NotNull(message = "username is mandatory")
    private String username;
    @NotNull(message = "email is mandatory")
    private String email;
    @NotNull(message = "password is mandatory")
    private String password;
    public long getUserId() {
        return userId;
    }
    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
